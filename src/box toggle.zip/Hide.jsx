import React from "react";
// import Box from "./Box";
import NewBox from "./NewBox";

function Hide() {
  return (
    <div id="boxes">
      <NewBox num={1} />
      <NewBox num={2} />
      <NewBox num={3} />
      <NewBox num={4} />
      <NewBox  num={5}/>
    </div>
  );
}

export default Hide;
