import React, { useState } from "react";
import ArrowDropUpIcon from "@mui/icons-material/ArrowDropUp";

function NewBox(props) {
  const [status, setStatus] = useState({
    box1: true,
    box2: true,
    box3: true,
    box4: true,
    box5: true,
  });

  function handleClick() {
    console.log(`box${props.num}`);
    // {

    //     box2: "garvit pagal hai",
    //     box3: "garvit pagal hai",
    //     box4: "garvit pagal hai",
    //     box1: "garvit pagal nahi hai"
    // }

    setStatus({
      ...status,
      [`box${props.num}`]: !status[`box${props.num}`],
    });
  }
  console.log(status);

  return (
    <>
      <div className="head" id={`box${props.num}`}>
        <h2>
          Box {props.num} <ArrowDropUpIcon onClick={handleClick} />
        </h2>
        <div id="main" className={status[`box${props.num}`] ? "visible" : ""}>
          <img src="https://placehold.co/300x200" alt="" />
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt a
            est aliquid cumque doloremque dolor quaerat blanditiis commodi
            ducimus voluptates.
          </p>
        </div>
      </div>
    </>
  );
}

export default NewBox;
